import { Category } from "./category"
import { User } from "./user"


export class Event
{
eventId:number=0;
user:User;
eventTitle:String;
eventDescription:String;
eventLocation:String;
eventDate:any;
eventTime:any;
eventCapacity:number;
pic:BinaryType;
eventCharges:number;  
category:Category;  
}