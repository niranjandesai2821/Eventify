export class User
{
userId:number=0;
username:String='';
password:String='';
 email:any;
    


}