package com.Spring.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.Spring.model.Events;

import com.Spring.repositories.EventRepository;


@Service
public class EventService 
{
	@Autowired
	EventRepository eventrepo;

	public List<Events> listofEvents()
	{
		return eventrepo.findAll();
	}
	
	public Events findbyid(int eventid)
	{
		return eventrepo.findById(eventid).get();
	}
	
	public boolean deletebyid(int eventid)
	{
		eventrepo.deleteById(eventid);
		return true;
	}
	
	public Events addrecord(Events ed)
	{
		return eventrepo.saveAndFlush(ed);
	}
	
	public Events updaterecord(Events ed)
	{
		return eventrepo.saveAndFlush(ed);
	}
	

}
