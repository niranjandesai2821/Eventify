package com.Spring.services;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Spring.model.Categories;
import com.Spring.repositories.CategoryRepository;

@Service
public class CategoryService 
{
	@Autowired
	CategoryRepository catrepo;
	
	public List<Categories> listofcategories()
	{
		return catrepo.findAll();
	}
	
	public Categories findbyid(int catid)
	{
		return catrepo.findById(catid).get();
	}
	
	public boolean deletebyid(int catid)
	{
		catrepo.deleteById(catid);
		return true;
	}
	
	public Categories addrecord(Categories ct)
	{
		return catrepo.saveAndFlush(ct);
	}
	
	public Categories updaterecord(Categories ct)
	{
		return catrepo.saveAndFlush(ct);
	}
	
	
}
