package com.Spring.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Spring.model.Registrations;

import com.Spring.repositories.RegistrationRepository;


@Service
public class RegistrationService 
{

	@Autowired
	RegistrationRepository registrationrepo;

	public List<Registrations> listofallRegistrations()
	{
		return registrationrepo.findAll();
	}
	
	
	public Registrations findbyid(int regid)
	{
		return registrationrepo.findById(regid).get();
	}
	
	public boolean deletebyid(int regid)
	{
		registrationrepo.deleteById(regid);
		return true;
	}
	
	
	public Registrations addrecord(Registrations rd)
	{
		return registrationrepo.saveAndFlush(rd);
	}
	
	public Registrations updaterecord(Registrations rd)
	{
		return registrationrepo.saveAndFlush(rd);
	}
	
	
}
