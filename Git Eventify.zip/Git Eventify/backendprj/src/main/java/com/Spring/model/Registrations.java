package com.Spring.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "registrations")
public class Registrations 
{

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private int registrationId;

	    @ManyToOne
	    @JoinColumn(name = "user_id")
	    private Users user;

	    @ManyToOne
	    @JoinColumn(name = "event_id")
	    private Events event;

		public int getRegistrationId() {
			return registrationId;
		}

		public void setRegistrationId(int registrationId) {
			this.registrationId = registrationId;
		}

		public Users getUser() {
			return user;
		}

		public void setUser(Users user) {
			this.user = user;
		}

		public Events getEvent() {
			return event;
		}

		public void setEvent(Events event) {
			this.event = event;
		}

	    

	

	
	

}
