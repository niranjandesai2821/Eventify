package com.Spring.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Spring.model.Categories;
import com.Spring.services.CategoryService;

@RestController
@RequestMapping("category")
public class CategoryController 
{
	@Autowired
	CategoryService catserv;
	
	
	
	@GetMapping("Catlist")
	public List<Categories> getlist()
	{
		return catserv.listofcategories();
	}
	
	@PostMapping("addcat")
    public String addCategory(@RequestBody Categories ct) 
	{
        catserv.addrecord(ct);
        return "Record is added !";
    }
	
	@DeleteMapping("deletecat/{id}")
	public String deleteCategory(@PathVariable("id") int id)
	{
		catserv.deletebyid(id);
		return "Record get Deleted ! ";
	}
	
	@GetMapping("findcat/{id}")
	public Categories find(@PathVariable("id") int id)
	{
		return catserv.findbyid(id);
		
	}
	
	@PutMapping("update")
	public String updateCategory(@RequestBody Categories ct)
	{
		catserv.updaterecord(ct);
		return "Record is Updated !";
	}
	
}












