package com.Spring.controllers;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.Spring.model.Events;

import com.Spring.services.EventService;


@RestController
@RequestMapping("events")
public class EventController 
{

	@Autowired
	EventService eventserv;

	@GetMapping("eventslist")
	public List<Events> getlist()
	{
		return eventserv.listofEvents();
	}
	
	@PostMapping("addevent")
    public String addEvent(@RequestPart ("data") Events ed, @RequestPart ("pic") MultipartFile pic) 
	{
		
		try {				
			ed.setPic(pic.getBytes());					
		} 
		catch (IOException e) {			
			e.printStackTrace();
		}

		
		
		
		
		
		eventserv.addrecord(ed);
        return "Record is added !";
    }
	
	@DeleteMapping("deleteevent/{id}")
	public String deleteEvent(@PathVariable("id") int id)
	{
		eventserv.deletebyid(id);
		return "Record get Deleted ! ";
	}
	
	@GetMapping("findevent/{id}")
	public Events findbyId(@PathVariable("id") int id)
	{
		return eventserv.findbyid(id);
	}
	
	
	@PutMapping("update")
	public String updateEvent(@RequestBody Events ed)
	{
		eventserv.updaterecord(ed);
		return "Record is Updated !";
	}
}
