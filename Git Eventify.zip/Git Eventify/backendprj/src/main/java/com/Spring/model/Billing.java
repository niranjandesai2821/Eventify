package com.Spring.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "billing")
public class Billing 
{

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private int billingId;

	    @ManyToOne
	    @JoinColumn(name = "registration_id")
	    private Registrations registration;

	    private double amount;
	    
	    private String paymentStatus;
	
	    private String paymentMethod;

		public int getBillingId() {
			return billingId;
		}

		public void setBillingId(int billingId) {
			this.billingId = billingId;
		}

		public Registrations getRegistration() {
			return registration;
		}

		public void setRegistration(Registrations registration) {
			this.registration = registration;
		}

		public double getAmount() {
			return amount;
		}

		public void setAmount(double amount) {
			this.amount = amount;
		}

		public String getPaymentStatus() {
			return paymentStatus;
		}

		public void setPaymentStatus(String paymentStatus) {
			this.paymentStatus = paymentStatus;
		}

		public String getPaymentMethod() {
			return paymentMethod;
		}

		public void setPaymentMethod(String paymentMethod) {
			this.paymentMethod = paymentMethod;
		}


	


}
