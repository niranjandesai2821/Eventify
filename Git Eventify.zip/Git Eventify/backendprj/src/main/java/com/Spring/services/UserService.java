package com.Spring.services;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Spring.model.Users;
import com.Spring.repositories.UserRepository;

@Service
public class UserService 
{
	@Autowired
	UserRepository userrepo;
	
	
	public boolean checkuser(Users u)
	{
		Users us = userrepo.findAll().stream()
		.filter(m->m.getUsername().toLowerCase().equals(u.getUsername().toLowerCase()))
		.collect(Collectors.toList()).get(0);                                                    //finding that user is valid user or not
		
		if(us!=null)
			return true;
		else
			return false;		
	}

	public List<Users> listofusers()
	{
		return userrepo.findAll();
	}
	
	public Users findbyid(int userid)
	{
		return userrepo.findById(userid).get();
	}
	
	public boolean deletebyid(int userid)
	{
		userrepo.deleteById(userid);
		return true;
	}
	
	public Users addrecord(Users ud)
	{
		return userrepo.saveAndFlush(ud);
	}
	
	public Users updaterecord(Users ud)
	{
		return userrepo.saveAndFlush(ud);
	}
	
}
