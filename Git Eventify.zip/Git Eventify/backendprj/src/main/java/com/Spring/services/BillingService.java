package com.Spring.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Spring.model.Billing;

import com.Spring.repositories.BillingRepository;


@Service
public class BillingService 
{

	@Autowired
	BillingRepository billingrepo;

	public List<Billing> listofallBills()
	{
		return billingrepo.findAll();
	}
	
	
	public Billing findbyid(int billid)
	{
		return billingrepo.findById(billid).get();
	}
	
	public boolean deletebyid(int billid)
	{
		billingrepo.deleteById(billid);
		return true;
	}
	
	
	public Billing addrecord(Billing bd)
	{
		return billingrepo.saveAndFlush(bd);
	}
	
	public Billing updaterecord(Billing bd)
	{
		return billingrepo.saveAndFlush(bd);
	}
	
	
}
