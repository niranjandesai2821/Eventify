package com.Spring.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.Spring.model.Users;
import com.Spring.services.UserService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("user")
public class UserController 
{
	@Autowired
	UserService userserv;
	
	
	@CrossOrigin(origins="http:/localhost:4200/")
	@PostMapping("checkuser")
	public ResponseEntity<Boolean> checkUser(@RequestBody Users u)
	{
		try
		{
			System.out.println(u.getUserId());
			boolean b = userserv.checkuser(u);
			if(!b)
				return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
			
			return ResponseEntity.ok(b);
		}
		catch(Exception e)
		{
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
		
	}
	

	@GetMapping("userslist")
	public List<Users> getlist()
	{
		return userserv.listofusers();
	}
	
	@PostMapping("adduser")
    public String addUser(@RequestBody Users ud) 
	{
        userserv.addrecord(ud);
        return "Record is added !";
    }
	
	@DeleteMapping("deleteuser/{id}")
	public String deleteUser(@PathVariable("id") int id)
	{
		userserv.deletebyid(id);
		return "Record get Deleted ! ";
	}
	
	@GetMapping("finduser/{id}")
	public Users find(@PathVariable("id") int id)
	{
		return userserv.findbyid(id);
		
	}
	
	@PutMapping("update")
	public String updateCategory(@RequestBody Users ud)
	{
		userserv.updaterecord(ud);
		return "Record is Updated !";
	}
	
}

