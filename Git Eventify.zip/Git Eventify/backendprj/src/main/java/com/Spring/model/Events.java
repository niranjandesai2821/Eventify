package com.Spring.model;

import java.sql.Blob;
import java.time.LocalDate;

import java.time.LocalTime;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name ="events")
public class Events
{
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private int eventId;

	    @ManyToOne
	    @JoinColumn(name = "user_id")
	    private Users user;

	    private String eventTitle;
	    private String eventDescription;
	    private String eventLocation;
	    private LocalDate eventDate;
	    private LocalTime eventTime;
	    private int eventCapacity;
	    
		@Column(name="pic")
		private byte[]  pic;
		
		@Column(name="eventCharges")
		private int eventCharges;
	    
//	    
//	    private ---  pic
//	    private -- food desc
//	    private foodcharges
//	    private eventcharges
	    

		public int getEventCharges() {
			return eventCharges;
		}

		
		public byte[] getPic() {
			return pic;
		}

		public void setPic(byte[] pic) {
			this.pic = pic;
		}

		public void setEventCharges(int eventCharges) {
			this.eventCharges = eventCharges;
		}

		public int getEventId() {
			return eventId;
		}

		public void setEventId(int eventId) {
			this.eventId = eventId;
		}

		public Users getUser() {
			return user;
		}

		public void setUser(Users user) {
			this.user = user;
		}

		public String getEventTitle() {
			return eventTitle;
		}

		public void setEventTitle(String eventTitle) {
			this.eventTitle = eventTitle;
		}

		public String getEventDescription() {
			return eventDescription;
		}

		public void setEventDescription(String eventDescription) {
			this.eventDescription = eventDescription;
		}

		public String getEventLocation() {
			return eventLocation;
		}

		public void setEventLocation(String eventLocation) {
			this.eventLocation = eventLocation;
		}

		public LocalDate getEventDate() {
			return eventDate;
		}

		public void setEventDate(LocalDate eventDate) {
			this.eventDate = eventDate;
		}

		public LocalTime getEventTime() {
			return eventTime;
		}

		public void setEventTime(LocalTime eventTime) {
			this.eventTime = eventTime;
		}

		public int getEventCapacity() {
			return eventCapacity;
		}

		public void setEventCapacity(int eventCapacity) {
			this.eventCapacity = eventCapacity;
		}

		public Categories getCategory() {
			return category;
		}

		public void setCategory(Categories category) {
			this.category = category;
		}

		@ManyToOne
	    @JoinColumn(name = "category_id")
	    private Categories category;

	


}
