import { Injectable } from '@angular/core';                        
import { HttpClient } from '@angular/common/http';
import { User } from '../models/user';
import { Observable } from 'rxjs';
import { Event } from '../models/events';
import { Category } from '../models/category';


@Injectable({
  providedIn: 'root'
})
export class CustomService {

  //This is Dependency injection we created,  created property to use that httpclient method and services
  constructor(private http:HttpClient) { }

  userexists(data:User)
  {
    return this.http.post("http://localhost:8080/user/checkuser",data)            //this data represents the JSON data which we are providing earlier from RESTAPI which is our @Requestbody
  }

  getAllEvents(): Observable<Event[]> {
    return this.http.get<Event[]>("http://localhost:8080/events/eventslist");
  }

  getAllCategories(): Observable<Category[]> {
    return this.http.get<Category[]>("http://localhost:8080/category/Catlist");
  }

}
