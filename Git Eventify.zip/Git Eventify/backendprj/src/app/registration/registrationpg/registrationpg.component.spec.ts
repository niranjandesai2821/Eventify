import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationpgComponent } from './registrationpg.component';

describe('RegistrationpgComponent', () => {
  let component: RegistrationpgComponent;
  let fixture: ComponentFixture<RegistrationpgComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RegistrationpgComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(RegistrationpgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
