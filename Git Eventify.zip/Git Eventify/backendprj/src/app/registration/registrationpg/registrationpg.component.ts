import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-registrationpg',
  templateUrl: './registrationpg.component.html',
  styleUrl: './registrationpg.component.css'
})
export class RegistrationpgComponent {

  userData = {
    username: '',
    email: '',
    password: ''
  };

  constructor(private http: HttpClient) {}

  registerUser() {
    this.http.post("http://localhost:8080/user/adduser", this.userData)
      .subscribe(
        (response) => {
          console.log('User registered successfully:', response);
          // Optionally, you can redirect the user to a different page after successful registration
        },
        (error) => {
          console.error('Error occurred during registration:', error);
        }
      );
  }

}
