import { Component,ElementRef,ViewChild } from '@angular/core';

@Component({
  selector: 'app-eventpg',
  templateUrl: './eventpg.component.html',
  styleUrl: './eventpg.component.css'
})
export class EventpgComponent 
{
  

}
