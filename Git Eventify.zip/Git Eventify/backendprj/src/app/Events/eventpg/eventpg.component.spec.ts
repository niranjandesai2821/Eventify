import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EventpgComponent } from './eventpg.component';

describe('EventpgComponent', () => {
  let component: EventpgComponent;
  let fixture: ComponentFixture<EventpgComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [EventpgComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(EventpgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
