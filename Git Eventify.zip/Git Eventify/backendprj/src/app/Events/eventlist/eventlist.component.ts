// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-eventlist',
//   templateUrl: './eventlist.component.html',
//   styleUrl: './eventlist.component.css'
// })
// export class EventlistComponent {

// }


import { Component, OnInit } from '@angular/core';
import { CustomService } from '../../../services/custom.service';
import { Event } from '../../../models/events';


@Component({
  selector: 'app-event-list',
  templateUrl: './eventlist.component.html',
  styleUrls: ['./eventlist.component.css']
})
export class EventListComponent implements OnInit {
  events: Event[];

  constructor(private CustomService: CustomService) { }

  ngOnInit(): void {
    this.getEvents();
  }

  getEvents(): void {
    this.CustomService.getAllEvents()
      .subscribe(events => this.events = events);
  }

  getPicUrl(pic: BinaryType): string {
   
    return `data:image/jpeg;base64,${pic}`; 
  }
}
