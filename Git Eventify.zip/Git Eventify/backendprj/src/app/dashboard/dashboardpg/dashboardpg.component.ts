import { Component } from '@angular/core';


@Component({
  selector: 'app-dashboardpg',
  templateUrl: './dashboardpg.component.html',
  styleUrl: './dashboardpg.component.css'
})
export class DashboardpgComponent {

}
