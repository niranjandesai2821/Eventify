import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AdminloginComponent } from './admin/adminlogin/adminlogin.component';
import { UserloginComponent } from './user/userlogin/userlogin.component';
import { HomepgComponent } from './home/homepg/homepg.component';
import { HttpClientModule } from '@angular/common/http';
import { DashboardpgComponent } from './dashboard/dashboardpg/dashboardpg.component';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatToolbarModule } from '@angular/material/toolbar';
import { AdminheaderComponent } from './admin/adminheader/adminheader.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { CategorypgComponent } from './category/categorypg/categorypg.component';
import { EventpgComponent } from './Events/eventpg/eventpg.component';
import { EventListComponent } from './Events/eventlist/eventlist.component';
import { RegistrationpgComponent } from './registration/registrationpg/registrationpg.component';

@NgModule({
  declarations:
   [
    AppComponent,
    AdminloginComponent,
    UserloginComponent,
    HomepgComponent,
    DashboardpgComponent,
    AdminheaderComponent,
    CategorypgComponent,
    EventpgComponent,
    EventListComponent,
    RegistrationpgComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule,HttpClientModule,MatIconModule,MatButtonModule,MatToolbarModule,
    RouterModule.forRoot([
      {path:"admin",component:AdminloginComponent},
      {path:"",redirectTo:"admin",pathMatch:"full"},
      {path:"home",component:UserloginComponent},
      {path:"dashboard",component:DashboardpgComponent},
      {path:"Events",component:EventpgComponent},
      {path:"Category",component:CategorypgComponent},
      {path:"registrationpg",component:RegistrationpgComponent}



    ])
  ],
  providers: [
    provideClientHydration(),
    provideAnimationsAsync()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
