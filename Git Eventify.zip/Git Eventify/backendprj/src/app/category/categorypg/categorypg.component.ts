import { Component } from '@angular/core';

@Component({
  selector: 'app-categorypg',
  templateUrl: './categorypg.component.html',
  styleUrl: './categorypg.component.css'
})
export class CategorypgComponent {

}
