import { Component } from '@angular/core';
import { CustomService } from '../../../services/custom.service';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrl: './adminlogin.component.css'
})
export class AdminloginComponent {

  // username: string='';
  // password: string='';

  // //constructor is hook , and used for dependency injection of multiple modules or services 
  // constructor(private customserv :CustomService, private route: Router){}

  
  // onSubmit()
  // {
  //   let obj={userId:0,username:this.username,password:this.password,email:''}          //now this object we are sending as a data
  //   this.customserv.userexists(obj).subscribe(
  //                                                  response => 
  //                                                  {
  //                                                   console.log(response)
  //                                                   if(response)
  //                                                   {
  //                                                     this.route.navigate(["/dashboard"])
  //                                                   }
  //                                                  },
  //                                                 error=> console.log(error)
  //                                            );


  // }

  username: string;
  password: string;

  constructor(private customserv :CustomService, private route: Router){}



  login()
   {
    let obj={userId:0,username:this.username,password:this.password,email:''}          //now this object we are sending as a data
    this.customserv.userexists(obj).subscribe(
                                                   response => 
                                                   {
                                                    console.log(response)
                                                    if(response)
                                                    {
                                                      this.route.navigate(["/dashboard"])
                                                    }
                                                   },
                                                  error=> console.log(error)
                                             );

   }

}
